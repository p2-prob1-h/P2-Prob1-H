public interface FormatoSimples {
    public void reproduzirSimples(String flie);
    public void pararSimples();
}
