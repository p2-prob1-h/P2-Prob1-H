

public class wmaPlay
    implements FormatoAudio, FormatoSimples{
    private String file;
    private int location;

    
    @Override
    public void abrir(String file) {
        System.out.println("Audio abriu");
        this.file = file;
    }

    @Override
    public void reproduzir() {
        System.out.println("Audio reproduzindo");
    }

    @Override
    public void pausar() {
        System.out.println("Audio Pausado");
    }

    @Override
    public void parar() {
        System.out.println("Audio reiniciado e parado");
    }

    @Override
    public void avancar(int qntSegundos) {
        System.out.println("Avançou " + qntSegundos + " segundos");
    }

    @Override
    public void retornar(int qntSegundos) {
        System.out.println("Retornou " + qntSegundos + " segundos");
    }

    @Override
    public void liberar() {
        System.out.println("Arquivo fechado e memoria liberada");
    }

    
    @Override
    public void reproduzirSimples(String flie) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void pararSimples() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
