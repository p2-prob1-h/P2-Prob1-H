/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author jhchiarelli
 */
public class aaaa {
    private String file;
    private int location;
    
    public void setFile(String file){
        this.file = file;
    }
    
    public void setLocation(int location){
        this.location = location;
    }
    
    public int getLocation(){
        return this.location;
    }
    
    public void open(){
        System.out.println("Musica abriu");
    }
    
    public void play(){
        System.out.println("Musica tocando");
    }
    
    public void stop(){
        System.out.println("Musica parada");  //adionar proxima mensagem play
    }
}
